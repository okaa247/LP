from django.views.generic import View
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView
from django.contrib.auth import get_user_model
from .models import *
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.views import View
from django.contrib import messages


class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirect to a success page or home
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})


class Home(View):
    def get(self, request):
  
        return render(request, 'index.html',)
    




class RegistrationView(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self, request):
        email = request.POST['email']
        username = request.POST['username']
        fullname = request.POST['fullname']
        password = request.POST['password']
        phone_number = request.POST['phone_number']
    
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
            return redirect('register')
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username alradey exists')
            return redirect('register')

        user = User.objects.create_user(
            email=email,
            username=username,
            fullname=fullname,
            phone_number=phone_number,
            password=password
        )
        user.save()
        return redirect('login')


# class UserRegistrationView(CreateView):
#     model = User
#     template_name = 'register.html'
#     success_url = reverse_lazy('login')
#     fields = ['username', 'password', 'email',]

#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context['title'] = 'Register'
#         return context

#     def form_valid(self, form):
#         user = form.save(commit=False)
#         user.set_password(self.request.POST['password'])
#         user.save()
#         return super().form_valid(form)

